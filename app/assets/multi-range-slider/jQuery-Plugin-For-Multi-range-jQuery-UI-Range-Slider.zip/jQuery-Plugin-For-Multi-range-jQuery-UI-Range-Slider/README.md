**Jquery UI Range Slider**
===================

Displays a flexible slider with multiples ranges

You can see the demo here: http://emilioforrer.github.io/jquery-ui-range-slider/

----------

**Requirements**
------------

* **jQuery UI v1.10.x or superior**


**Documentation**
------------

**TODO**



----------


## **Copyright**

Copyright (c) 2015 Emilio Forrer. See LICENSE.txt for further details.
